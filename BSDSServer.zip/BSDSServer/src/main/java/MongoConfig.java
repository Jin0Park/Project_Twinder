import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoConfig {

    String databaseName = "TwinderDB";
    String collectionName = "twinders";
    String ec2IPv4ForMongoDB = "35.90.20.84";
    private MongoClient mongoClient;
    private MongoDatabase database;
    private static MongoConfig instance = null;
    private String mongoUri;

    public static MongoConfig getInstance() {
        if(instance == null)
            instance = new MongoConfig();
        return instance;
    }

    private MongoConfig() {
        mongoUri = "mongodb://admin:password@" + ec2IPv4ForMongoDB + ":27017/?maxPoolSize=50";

//        String connectionString = "mongodb+srv://twinder_username:twinder_password@twindercluster.rdueczb.mongodb.net/?retryWrites=true&w=majority";
//        MongoClientSettings settings = MongoClientSettings.builder()
//                .applyConnectionString(new ConnectionString(connectionString))
//                .build();
        mongoClient = MongoClients.create(mongoUri);
        database = mongoClient.getDatabase("TwinderDB");
    }

    public MongoClient getMongoClient() {
        return mongoClient;
    }

    public MongoDatabase getDatabase() {
        return database;
    }
}
