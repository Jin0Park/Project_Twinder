public class InvalidResponse {
    String message;

    public String getMessage() {
        return message;
    }

    public InvalidResponse(String message) {
        this.message = message;
    }
}
